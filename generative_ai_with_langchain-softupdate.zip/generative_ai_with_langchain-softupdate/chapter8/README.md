# Chapter 8 - Customizing LLMs and Their Output

| Section	| File | Colab	 | Kaggle	| Gradient |
|-----------|--------|--------|-----------|----------|
| Prompting | [diverse prompting examples](prompting)  |        | | |
| Fine-tuning example  |  [notebook](fine_tuning.ipynb)   |       |  |   |

