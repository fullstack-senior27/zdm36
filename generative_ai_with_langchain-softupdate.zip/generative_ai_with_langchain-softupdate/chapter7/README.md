# Chapter 7 - LLMs for Data Science

| Section	| File | Colab	 | Kaggle	| Gradient |
|-----------|--------|--------|-----------|----------|
| Example of data analysis | [notebook](data_science.ipynb)  |        | | |
| Interactive GUI for data analysis  |  [python script](app.py)   |  x      | x | x |

